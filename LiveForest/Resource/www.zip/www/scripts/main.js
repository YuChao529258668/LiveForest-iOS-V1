var lat = 118.786951,
    lon = 32.037118,
    targetIndex = 0,
    zoomLevel = 15,
    keywords = "运动",
    targetPoint = {},
    poiResultArr = [];
// minPoi = new BMap.Point(lat, lon),
// maxPoi = new BMap.Point(lat, lon);;
//keywords = ["运动馆", "健身馆", "瑜伽馆"];


//可是使用个性化在线编辑器地址：http://developer.baidu.com/map/custom/,拷贝里面的JSON
var styleJson = [
    {
        "featureType": "poi",
        "elementType": "all",
        "stylers": {
            "visibility": "off"
        }
    },
    {
        "featureType": "land",
        "elementType": "all",
        "stylers": {
            "color": "#a3cf62"
        }
    },
    {
        "featureType": "manmade",
        "elementType": "geometry.fill",
        "stylers": {
            "color": "#a3cf62"
        }
    },
    {
        "featureType": "building",
        "elementType": "geometry.fill",
        "stylers": {
            "color": "#a3cf62"
        }
    },
    {
        "featureType": "water",
        "elementType": "geometry.fill",
        "stylers": {
            "color": "#95e2f4"
        }
    },
    {
        "featureType": "road",
        "elementType": "geometry.fill",
        "stylers": {
            "color": "#ffe599"
        }
    },
    {
        "featureType": "all",
        "elementType": "labels",
        "stylers": {
            "visibility": "off"
        }
    }
];


/**
 * 标注点击事件
 * @param event 出入事件
 */
function treasureClick(event) {
    console.log("(" + event["target"]["point"]["lng"] + "," + event["target"]["point"]["lat"] + ")" + event["type"]);

}
//
/**
 * 自定义标注,根据type,lat,lon返回对应marker的view
 * @param point 地图点得实例
 * @returns {*}
 */
function getMarker(point) {
    var marker;
    switch (point["type"]) {
        case 1 :
            //console.log("1");
            marker = new BMap.Marker(new BMap.Point(point["point"]["lng"], point["point"]["lat"]), {"enableMassClear": false});
            marker.addEventListener("click", treasureClick);
            //marker.setLabel("label");
            break;
        case 2 :
            //console.log("2");
            marker = new BMap.Marker(new BMap.Point(point["point"]["lng"], point["point"]["lat"]));
            marker.addEventListener("click", treasureClick);
            break;

    }
    return marker;

}
/**
 * 步行路径规划
 * @param map   地图对象实例
 * @param tempOverlay   地图点终点
 */
function walkSearch(map, tempOverlay) {
    ////路径规划

    var walking = new BMap.WalkingRoute(map, {
        renderOptions: {
            map: map,
            autoViewport: false
        },
        onMarkersSet: function (pois) {
            //路径规划完毕设置起点和重点，删除即可
            //console.log(pois);
            console.log("绘制起点和终点");
            map.clearOverlays();
            for (var i = 0; i < poiResultArr.length; i++) {
                //console.log(poiResultArr[i]);
                var markerView = getMarker(poiResultArr[i]);
                map.addOverlay(markerView);
            }
            map.centerAndZoom(new BMap.Point(lat, lon), zoomLevel);
            //map.setMapStyle({styleJson: styleJson});
            //绘制起点
            var srcIcon = new BMap.Icon("http://developer.baidu.com/map/jsdemo/img/Mario.png", new BMap.Size(32, 70));
            var srcMarker = new BMap.Marker(new BMap.Point(lat, lon), {icon: srcIcon, "enableMassClear": false});	// 创建标注
            map.addOverlay(srcMarker);              			 // 将标注添加到地图中
            //$("#container").css({
            //    "z-index": 9999
            //});
        },
        onPolylinesSet: function (routes) {
            //回执路径
            console.log("onPolylinesSet");

            //$("img").hide();
            //$("#container").
            //map.centerAndZoom(new BMap.Point(lat, lon), zoomLevel);

        }
    });
    //debugger;
    //tempOverlay =  poiResultArr[]
    walking.search(new BMap.Point(lat, lon),
        new BMap.Point(tempOverlay["point"]["lng"], tempOverlay["point"]["lat"]));

    //$("#loadingGif").hide();
    //$("#container").show();
    //$("#container").css({
    //    "z-index" : 9999
    //});
    //$("#container").css({"width": "100%", "height": "100%"});
    //map.centerAndZoom(new BMap.Point(lat, lon), zoomLevel);
    ////绘制起点
    //var srcIcon = new BMap.Icon("http://developer.baidu.com/map/jsdemo/img/Mario.png", new BMap.Size(32, 70));
    //var srcMarker = new BMap.Marker(new BMap.Point(lat, lon), {icon: srcIcon, "enableMassClear": false});	// 创建标注
    //map.addOverlay(srcMarker);              			 // 将标注添加到地图中
    //console.log(tempOverlay);

}

/**
 * POI搜索 POI完成的回调函数onSearchComplete
 * @param map 传入地图实例对象
 */
function poiSearch(map) {
    var currentPageNum = 0;
    map.centerAndZoom(new BMap.Point(lat, lon), zoomLevel);
    var local = new BMap.LocalSearch(
        map,
        {
            renderOptions: {},
            onSearchComplete: function (results) {
                //POI检索完成函数
                localResult = local.getResults();
                targetIndex = Math.floor((Math.random() * 100) % localResult["Sz"]);

                if (currentPageNum < localResult.getNumPages()) {
                    //遍历当前页的poi结果
                    for (var i = 0; i < localResult.getCurrentNumPois(); i++) {
                        var temp = localResult.getPoi(i);
                        var poiTemp = {
                            "title": temp["title"],
                            "point": temp["point"],
                            "address": temp["address"],
                            "type": 1
                        };
                        poiResultArr.push(poiTemp);
                        //poiResultArr.push(new BMap.Point(poiTemp["point"]["lng"], poiTemp["point"]["lat"]));
                        var marker = getMarker(poiTemp);
                        //map.addOverlay(marker);
                        //console.log("设置藏宝点" + (i + currentPageNum * 10));
                    }
                    ;
                    //进入下一页,重新进入回调函数
                    currentPageNum++;
                    local.gotoPage(currentPageNum);

                } else {
                    //遍历完成
                    //随机终点
                    //设置终点弹跳效果
                    //$("img").remove();
                    //$("#container").show();


                    //var allOverlay = map.getOverlays();
                    //var tempOverlay = allOverlay[targetIndex];
                    //console.log(poiResultArr[targetIndex]);
                    //console.log(allOverlay);
                    //console.log(targetIndex);
                    //console.log(tempOverlay);
                    //tempOverlay.setAnimation(BMAP_ANIMATION_BOUNCE);
                    //tempOverlay.setLabel("终点");
                    //tempOverlay.setTop();
                    //tempOverlay.enableDragging();

                    walkSearch(map, poiResultArr[targetIndex]);
                    //获取全部poi point之后，计算viewport，让地图处于最佳显示状态
                    ////var viewport = map.getViewport(poiResultArr);
                    ////map.centerAndZoom(new BMap.Point(viewport["center"]["lng"], viewport["center"]["lat"]), viewport["zoom"]);
                }
                //获取全部poi point之后，计算viewport，让地图处于最佳显示状态
                //if (poiResultArr.length == localResult.getNumPois()) {
                //	var viewport = map.getViewport(poiResultArr);
                //	map.centerAndZoom(new BMap.Point(viewport["center"]["lng"], viewport["center"]["lat"]), viewport["zoom"]);
                //};
            },
            autoViewport: false
        }
    );
    //local.search(keywords, map.getBounds());
    //local.disableFirstResultSelection();
    local.searchNearby(keywords, new BMap.Point(lat, lon), 500);
}


/**
 * 地图初始化方法&增加地图起点&出发POI搜索
 * @param styleJson 地图底图的样式JSON
 */
function init() {
    // 创建Map实例
    map = new BMap.Map("container", {enableMapClick: false});
    // 设置底图
    map.setMapStyle({styleJson: styleJson});
    //初始化地图中心
    //var start = new BMap.Point(lat, lon); 			    // 创建点坐标
    //map.centerAndZoom(start, zoomLevel);
    //配置地图缩放属性
    map.disableInertialDragging();                      //禁用地图惯性拖拽
    map.disableDragging();                              //禁用地图拖拽。
    map.disableScrollWheelZoom();                       //禁用滚轮放大缩小。
    map.disablePinchToZoom();                           //禁用双指操作缩放。
    map.disableScrollWheelZoom();                       //禁用滚轮放大缩小。
    map.disableDoubleClickZoom();                       //禁用双击放大。
    map.disableKeyboard();                              //禁用键盘操作。
    //POI检索
    poiSearch(map);
}

/**
 * 异步加载百度地图,异步加载完成自动调用init函数
 */
function loadJScript() {
    console.log(new Date());
    //window.clearInterval(int);
    var script = document.createElement("script");
    script.type = "text/javascript";
    script.src = "http://api.map.baidu.com/api?v=2.0&ak=R2FaL2ojRCekbPbdFVj0y0Rw&callback=init";
    document.body.appendChild(script);

}

/**
 * 异步加载GIF资源
 * @param target 加载GIF的父对象,必须是一个Jquery/Zepto对象,因为函数中使用了append函数
 * @param url 图片资源url
 * @param callback 异步加载完成回调函数
 */
function loadGif(target, url, callback) {
    //var gif = new Image();
    //gif.onload = function () {
    //    console.log("gif loaded");
    //    //target.append(gif);
    //    //debugger;
    //    //callback();
    //    //canvas.drawImage(gif, 0, 0);
    //    //debugger;
    //    context.drawImage(gif, 0, 0);
    //    //console.log(new Date());
    //    //int = self.setInterval("loadJScript()", 3000);
    //};
    //gif.src = url;


    //$(gif).attr("id", "loadingGif");
    //$("#container").hide();

    //$(gif).css({
    //    width: $(window).width(),
    //    height: $(window).height(),
    //    position: "absolute",
    //    "z-index": 999
    //});

    //int = self.setInterval("loadJScript()", 3000);
    gifTimer = setInterval(function () {
        currentFrame = (currentFrame + 1) % gifFrames;
        total++;
        erfa = total * w;
        wx_posx = centerx + radius * Math.cos(erfa);
        wx_posy = centery + radius * Math.sin(erfa);
        console.log(wx_posx+"\t"+wx_posy);
        img.src = "img/" + (currentFrame + 1) + ".png";
        if (total == 6000 / 200) {
            console.log(new Date());
            window.clearInterval(gifTimer);
            //$("canvas").hide();
            //$("canvas").css({
            //    width: $(window).width(),
            //    height: $(window).height(),
            //    position: "absolute",
            //    "z-index": 1
            //});
            $("#container").css({
                "z-index": 9999
            });
            $("#xuanya").show();
        }
    }, 200);


    loadJScript();
};


//init canvas
//loadGif($("body"), "test.gif", loadJScript);
$("canvas").css({
    width: $(window).width(),
    height: $(window).height(),
    position: "absolute",
    "z-index": 999
});
$("img").css({
    height: $(window).height()
});
var windowWith = $(window).width();
var windowHeight = $(window).height();
var canvas = document.getElementById("loadingGif");
canvas.width = $(window).width();
canvas.height = $(window).height();
var context = canvas.getContext("2d");
var gifFrames = 22;
var currentFrame = 0;
var total = 0;
wx_posx = 0, wx_posy = 0, radius = 100, round = 3;//(卫星6s转几圈)
w = Math.floor( 2 * Math.PI * radius * round / 6);//角速度
//console.log(w);
centerx = windowWith / 2, centery = windowHeight / 2;
erfa = 0;
wx_posx = centerx + radius * Math.cos(erfa);
wx_posy = centery + radius * Math.sin(erfa);

var img = new Image();
var img2 = new Image();
img2.onload = function () {
    console.log("wx loaded");
    //context.drawImage(img2, 0, 0);
};
img2.src = "img/wx.png";

img.onload = function () {
    console.log("img标签成功加载" + currentFrame + "帧图片");
    context.clearRect(0, 0, windowWith, windowHeight);
    context.drawImage(img, centerx, centery);
    context.drawImage(img2, wx_posx, wx_posy);
    //console.log(wx_posx+"\t"+wx_posy);

};
img.src = "img/" + (currentFrame + 1) + ".png";
total++;
console.log(new Date());
loadGif($("body"), "test.gif", loadJScript);